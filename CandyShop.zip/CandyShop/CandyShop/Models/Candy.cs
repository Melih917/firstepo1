﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CandyShop.Models
{
    public class Candy
    {
        public int Id { get; set; }
        public string CandyName { get; set; }
        public string Type { get; set; }
        public enum Flavor
        {
            Mysterious,
            Sweet,
            Bitter
        }
        public Flavor Flavors { get; set; }
        public string ImageUrl { get; set; }
        public DateTime DurabilityEndDate { get; set; }
        public double Price { get; set; }
        public ICollection<Reservation> Reservations { get; set; }
    }
}
