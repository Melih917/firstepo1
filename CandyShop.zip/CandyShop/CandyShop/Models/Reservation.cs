﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CandyShop.Models
{
    public class Reservation
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public DateTime ReservationDate { get; set; }

        public DateTime PickupDate { get; set; }

        public int Quantity { get; set; }

        public virtual Candy Candy { get; set; }

    }
}
